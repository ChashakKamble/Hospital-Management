# Hospital-Management
hospital management website with the backend of the express js frame work
